//******************************************************************************
//   MSP430G2xx3 Demo - USCI_A0, 115200 UART Echo ISR, DCO SMCLK
//
//   Description: Echo a received character, RX ISR used. Normal mode is LPM0.
//   USCI_A0 RX interrupt triggers TX Echo.
//   Baud rate divider with 1MHz = 1MHz/115200 = ~8.7
//   ACLK = n/a, MCLK = SMCLK = CALxxx_1MHZ = 1MHz
//
//                MSP430G2xx3
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |     P1.2/UCA0TXD|------------>
//            |                 | 115200 - 8N1
//            |     P1.1/UCA0RXD|<------------
//
//   D. Dang
//   Texas Instruments Inc.
//   February 2011
//   Built with CCS Version 4.2.0 and IAR Embedded Workbench Version: 5.10
//******************************************************************************
#include  "msp430g2553.h"
#include <legacymsp430.h>
#include <inttypes.h>

/* Pin config:
 * Left encoder:
 * 	Phase A up -> P2.0
 * 	Phase B up -> P2.1
 * 	Phase B down -> P2.2
 * Right Encoder:
 * 	Phase A up -> P2.3
 * 	Phase B up -> P2.4
 * 	Phase B down -> P2.5
 */

uint16_t encl = 0, encr = 0, pencl = 0, pencr = 0;
uint8_t i = 0, l1, l2, r1, r2;
int lstate = 0, rstate = 0;
char received = '\0';

int main(void){
  // Stop WDT
  WDTCTL = WDTPW + WDTHOLD;
  // Init UART
  BCSCTL1 = CALBC1_1MHZ;                    // Set DCO
  DCOCTL = CALDCO_1MHZ;
  P1SEL = BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
  P1SEL2 = BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
  UCA0CTL1 |= UCSSEL_2;                     // SMCLK
  UCA0BR0 = 8;                            // 1MHz 115200
  UCA0BR1 = 0;                              // 1MHz 115200
  UCA0MCTL = UCBRS2 + UCBRS0;                        // Modulation UCBRSx = 1
  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt
  // Initialize pins
  P1DIR |= BIT0 + BIT6;
  P1OUT &= ~(BIT0 + BIT6);
  // Init Interrupts
  P2IE |= BIT0+BIT5;
  P2IES &= ~(BIT0 + BIT5);
  P2IFG &= ~(BIT0+BIT5);
 
 // Enter LPM0 w/ interrupts enabled
  __bis_SR_register(GIE);
  while(1);
}

// #pragma vector=USCIAB0RX_VECTOR
interrupt (USCIAB0RX_VECTOR ) USCI0RX_ISR (void)
{
  received = UCA0RXBUF;
  if (received == 'S'){
    pencl = encl;
    encl = 0;
    pencr = encr;
    encr = 0;
    l1 = (pencl&0b00011111) | 0b10100000;
    l2 = ((pencl>>5)&0b00011111) | 0b01000000;
    r1 = (pencr&0b00011111) | 0b11000000;
    r2 = ((pencr>>5)&0b00011111) | 0b01100000;
  }else if(received == 'l'){
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = l1;
  }else if(received == 'L'){
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = l2;
  }else if(received == 'r'){
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = r1;
  }else if(received == 'R'){
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = r2;
  }
}

interrupt (PORT2_VECTOR ) Port_2 (void)
{
  switch(P2IFG&0x21)
  {
    case 0x01:
      encl++;
      P1OUT ^= BIT6;
      P2IFG &= ~BIT0;     
      break;
    case 0x20:
      encr++;
      P1OUT ^= BIT0;
      P2IFG &= ~BIT5;
      break;
    case 0x21:
      encl++;
      encr++;
      P1OUT ^= BIT0 + BIT6;
      P2IFG &= ~(BIT0 + BIT5);
      break;
  }
}
