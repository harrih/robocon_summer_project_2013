//******************************************************************************
//   MSP430G2xx3 Demo - USCI_A0, 9600 UART Echo ISR, DCO SMCLK
//
//   Description: Echo a received character, RX ISR used. Normal mode is LPM0.
//   USCI_A0 RX interrupt triggers TX Echo.
//   Baud rate divider with 1MHz = 1MHz/9600 = ~104.2
//   ACLK = n/a, MCLK = SMCLK = CALxxx_1MHZ = 1MHz
//
//                MSP430G2xx3
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |     P1.2/UCA0TXD|------------>
//            |                 | 9600 - 8N1
//            |     P1.1/UCA0RXD|<------------
//
//   D. Dang
//   Texas Instruments Inc.
//   February 2011
//   Built with CCS Version 4.2.0 and IAR Embedded Workbench Version: 5.10
//******************************************************************************
#include  "msp430g2553.h"
#include <legacymsp430.h>
#include <inttypes.h>

int8_t encl = 0, encr = 0, pencl = 0, pencr = 0;
int lstate = 2, rstate = 2;

void main(void)
{
  // Stop WDT
  WDTCTL = WDTPW + WDTHOLD;
  // Initialize pins
  P1DIR |= BIT0+BIT6;
  P1OUT &= ~(BIT0+BIT6);
  // Init UART
  BCSCTL1 = CALBC1_1MHZ;                    // Set DCO
  DCOCTL = CALDCO_1MHZ;
  P1SEL = BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
  P1SEL2 = BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
  UCA0CTL1 |= UCSSEL_2;                     // SMCLK
  UCA0BR0 = 8;                            // 1MHz 9600
  UCA0BR1 = 0;                              // 1MHz 9600
  UCA0MCTL = UCBRS2 + UCBRS0;                        // Modulation UCBRSx = 1
  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt
  // Init interrupts pins
  P2IE |= BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5;
  P2IES &= ~(BIT0 + BIT1 + BIT4 + BIT5);
  P2IES |= (BIT2 + BIT3);
  P2IFG &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5);
  // Enter LPM0 w/ interrupts enabled
   __bis_SR_register(GIE);  
}

interrupt (USCIAB0RX_VECTOR ) USCI0RX_ISR (void)
{
  if (UCA0RXBUF == 'S')                     // 'u' received?
  {
    pencl = encl;
    encl = 0;
    pencr = encr;
    encr = 0;
    IE2 |= UCA0TXIE;
    UCA0TXBUF = pencl;
  }
}

interrupt (USCIAB0TX_VECTOR ) USCI0TX_ISR (void)
{
  UCA0TXBUF = pencr;
  IE2 &= ~UCA0TXIE;
}

interrupt (PORT2_VECTOR ) Port_2 (void)
{
  switch(P2IFG&0x07)
  {
  case 0x01:
    if(lstate == 5){
      P1OUT |= BIT0;
      encl++;
    }
    else if(lstate == 6){
      P1OUT &= ~BIT0;
      encl--;     
    }
    lstate = 2;
    P2IFG &= ~BIT0;
    break;
  case 0x02:
    lstate++;
    P2IFG &= ~BIT1;
    break;
  case 0x04:
    lstate*=2;
    P2IFG &= ~BIT2;
    break;
  }
  switch(P2IFG&0x38)
  {
  case 0x20:
    if(rstate == 5){
      P1OUT |= BIT6;
      encr++;
    }
    else if(rstate == 6){
      P1OUT &= ~BIT6;      
      encr--;
    }
    rstate = 2;
    P2IFG &= ~BIT3;
    break;
  case 0x10:
    rstate++;
    P2IFG &= ~BIT4;
    break;
  case 0x08:
    rstate*=2;
    P2IFG &= ~BIT5;
  }
  P2IFG = 0x00;
}
