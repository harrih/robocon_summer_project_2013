/*
 * main.c
 * This is for handling Simultaneous interrupts.
 */
#include <msp430.h>
int encl = 0;
int encr = 0;

void main(void) {
	P1IES |= BIT0+BIT1;   // high -> low is selected with IES.x = 1.
	P1IFG &= ~BIT0;  // To prevent an immediate interrupt, clear the flag for
	P1IFG &= ~BIT1;   // P1.3 before enabling the interrupt.
	P1IE |= BIT0+BIT1;    // Enable interrupts for P1.3
	P2DIR |= BIT0+BIT1;
// 	P2OUT &= ~(BIT0+BIT1+BIT2+BIT3);

	_BIS_SR(GIE);
	while(1){
	/*	if(encl%2==0){
			P2OUT |= BIT0;
			P2OUT &= ~BIT1;
		}else{
			P2OUT |= BIT0;
			P2OUT &= ~BIT1;
		}
		if(encr%2==0){
			P2OUT |= BIT2;
			P2OUT &= ~BIT3;
		}else{
			P2OUT |= BIT2;
			P2OUT &= ~BIT3;
		}*/
	P2OUT &= ~(BIT0+BIT1);
	}
	
}

#pragma vector = PORT1_VECTOR
__interrupt void P1_ISR(void) {
    switch(P1IFG&0X03) {
        case 0X01:
            P1IFG &= ~BIT0;    // clear the interrupt flag
            encl++;
	    P2OUT |= BIT0;
            return;
        case 0x02:
            P1IFG &= ~BIT1;    // clear the interrupt flag
            encr++;
            P2OUT |= BIT1;
	    return;
        case 0x03:
            P1IFG &= ~(BIT0+BIT1);    // clear the interrupt flag
	    encl++;
	    encr++;
	    P2OUT |= BIT0+BIT1;
	    return;
    }
} // P1_ISR
