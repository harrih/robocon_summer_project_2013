#include <msp430.h>
#include <legacymsp430.h>

void main(void){
  WDTCTL = WDTPW + WDTHOLD;  // Stop WDT
  P1DIR |= BIT0 + BIT6;
  P1OUT &= 0x00;
  P1IE |= BIT4 + BIT5;
  P1IES |= BIT4 + BIT5;
  P1IFG &= ~(BIT4 + BIT5);
  _BIS_SR(GIE);
//   for(;;) {
// 	  volatile unsigned int i;	// volatile to prevent optimization
// 
// 	  P1OUT ^= 0x01;				// Toggle P1.0 using exclusive-OR
// 
// 	  i = 10000;					// SW Delay
// 	  do i--;
// 	  while(i != 0);
//   }
}


// Port 1 interrupt service routine
interrupt (PORT1_VECTOR ) Port_1 (void)
{
  switch(P1IFG&0x30)
  {
    case 0x10:
      P1OUT ^= BIT0;
      P1IFG &= ~BIT4;
      break;
    case 0x20:
      P1OUT ^= BIT6;
      P1IFG &= ~BIT5;
      break;
    case 0x30:
      P1OUT ^= BIT0+BIT6;      
      P1IFG &= ~(BIT4+BIT5);
      break;
  }
}